def fileRowCount(url): 
    try:
        f = open( url, 'r',encoding="utf-8")
        rowCount=len(f.readlines())
    finally:
        if f:
            f.close()
    return rowCount

