import re
import sys 
sys.path.append('C:\python-test\MyToolsPy')
import readFileLines 
import filterLstByStr
def filterFileListByFileData(fileList, matchStr , isRe):
    res =[]
    for fileUrl in fileList:
        lines=readFileLines.readFileLines(fileUrl)
        sa=filterLstByStr.filterLstByStr(lines,matchStr,isRe)
        if len(sa)>0:
            res.append(fileUrl)
    return res

            
