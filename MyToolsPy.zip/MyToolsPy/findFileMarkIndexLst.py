import re
import sys 
sys.path.append('C:\python-test\MyToolsPy')
import readFileLines 

def findFileMarkIndexLst(fileUrl, matchStr , isRe):
    res=[]
    lines=readFileLines.readFileLines(fileUrl)
    index=0
    for s in lines:
        if isRe ==True:
            pattern = re.compile(matchStr)
            if pattern.match(s):
                res.append(index)
        else:
            if s.find(matchStr) >=0:
                res.append(index)
        index=index +1
    return res
        
