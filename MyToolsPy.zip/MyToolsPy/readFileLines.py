def readFileLines(url):
    lines = []
    try:
        f = open( url, 'r',encoding="utf-8")
        lines=f.readlines()
    finally:
        if f:
            f.close()
    return lines

