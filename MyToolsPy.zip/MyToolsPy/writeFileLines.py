def writeFileLines(url,lines):
    try:
        with open(url, 'w',encoding="utf-8") as f:
            for line in lines:  
                f.write(line)
    finally:
        if f:
            f.close()
