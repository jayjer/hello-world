import sys 
sys.path.append('C:\python-test\MyToolsPy')
import readFileLines 
import writeFileLines

def fileDeleteRowsByIndex(fileUrl, indexLst ):
    lines=readFileLines.readFileLines(fileUrl)
    if len(indexLst)>0:
        indexLst = sorted(indexLst ,reverse=True)
        maxLineIndex=len(lines)
        for index in indexLst:
            if index<=maxLineIndex:
                lines.remove(lines[index])
    writeFileLines.writeFileLines(fileUrl,lines)


                

    
