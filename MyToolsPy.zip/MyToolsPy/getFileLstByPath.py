import os
#os.path.join(fpathe,f)
def getFileLstByPath(path):
     s = []
     for fpathe,dirs,fs in os.walk(path):
          for f in fs:
               s.append(fpathe+'/'+f) 
     return s;
     
     
