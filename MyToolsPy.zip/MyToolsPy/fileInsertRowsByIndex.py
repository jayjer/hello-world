import sys 
sys.path.append('C:\python-test\MyToolsPy')
import readFileLines 
import writeFileLines

def fileInsertRowsByIndex(fileUrl , indexList , insertRowList ,isBefFg):
    point = 1
    if isBefFg:
        point=0
    dictionary=dict(zip(indexList,insertRowList))
    lines=readFileLines.readFileLines(fileUrl)
    if len(indexList)>0:
        indexList = sorted(indexList ,reverse=True)
        maxLineIndex=len(lines)
        dictLen=len(dictionary)
        for dictKey in indexList:
            if dictKey<=maxLineIndex:
                lines.insert(dictKey+point, dictionary[dictKey]+'\n')
        writeFileLines.writeFileLines(fileUrl,lines)
        
        
                
                
            
        
    
