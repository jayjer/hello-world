import re
def filterLstByStr(lst, matchStr , isRe):
    res=[]
    for s in lst:
        if isRe ==True:
            pattern = re.compile(matchStr)
            if pattern.match(s):
                res.append(s)
        else:
            if s.find(matchStr) >=0:
                res.append(s)
    return res
            
            
                 
            
