import sys 
sys.path.append('C:\python-test\MyToolsPy')
import fileRowCount 
#fileRowCount.fileRowCount('C:/python-test/test.txt')

import readFileLines 
#lines=readFileLines.readFileLines('C:/python-test/test.txt')

import listStrReplace 
#lines=listStrReplace.listStrReplace(lines,'aaa','111')

import writeFileLines 
#writeFileLines.writeFileLines('C:/python-test/test.txt',lines)

import getFileLstByPath
sa=getFileLstByPath.getFileLstByPath('C:/python-test/MyToolsPy')

import filterLstByStr
sa=filterLstByStr.filterLstByStr(sa,'py',False)
sa = sa[:12]


import filterFileListByFileData
xx=filterFileListByFileData.filterFileListByFileData(sa,'abc',False)
for xxs in xx:
    print(xxs)

#our=[]
#for s in sa:
#    our.extend(readFileLines.readFileLines( s))
#writeFileLines.writeFileLines('C:/python-test/test1.txt',our)

import findFileMarkIndexLst
#indexLst=findFileMarkIndexLst.findFileMarkIndexLst('C:/python-test/cost.txt' ,'a' , False)

import fileDeleteRowsByIndex
#fileDeleteRowsByIndex.fileDeleteRowsByIndex('C:/python-test/cost.txt',indexLst)


import fileInsertRowsByIndex
#indexLst =[1,3,5]
#indexRowLst =['111111111','333aaaa','5555555dsfdsf']
#fileInsertRowsByIndex.fileInsertRowsByIndex('C:/python-test/cost.txt',indexLst ,indexRowLst ,False)


