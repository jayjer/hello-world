def listStrReplace(lines,repStr,chStr):
    index =0
    for line in lines:
        line=line.replace(repStr, chStr)
        lines[index] =line
        index=index+1
    return lines
